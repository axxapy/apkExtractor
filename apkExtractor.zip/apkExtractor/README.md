# apkExtractor

apkExtractor is an app for extracting apk's from your android device.
<br>
<a href="https://f-droid.org/repository/browse/?fdid=axp.tool.apkextractor" target="_blank">
  <img src="https://f-droid.org/badge/get-it-on.png" height="80"/>
</a>

<img src=https://raw.githubusercontent.com/axxapy/apkExtractor/screenshots/screenshots/one.png width=182><img src=https://raw.githubusercontent.com/axxapy/apkExtractor/screenshots/screenshots/two.png width=182><img src=https://raw.githubusercontent.com/axxapy/apkExtractor/screenshots/screenshots/three.png width=182><img src=https://raw.githubusercontent.com/axxapy/apkExtractor/screenshots/screenshots/four.png width=182>

Features
--------

* Extract free apps (no root needed)
* Extract paid apps (with root)
* Supports android >= 2.3.3 (api 10)

License
-------
MIT, see [LICENSE](https://raw.githubusercontent.com/axxapy/apkExtractor/master/LICENSE) file
